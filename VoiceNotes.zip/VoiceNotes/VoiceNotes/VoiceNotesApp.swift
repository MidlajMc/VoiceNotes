//
//  VoiceNotesApp.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftUI
import SwiftData

@main
struct VoiceNotesApp: App {
    @StateObject private var keyboard = KeyboardObserver()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(keyboard)
        }
        .modelContainer(for: Recording.self)
    }
}

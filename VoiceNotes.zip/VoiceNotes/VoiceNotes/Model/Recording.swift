//
//  Recording.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftData
import Foundation

@Model
class Recording {
    var id: UUID
    var title: String
    var fileName: String
    var date: Date
    var duration: TimeInterval
    var isShared: Bool = false
    var isStarred: Bool = false
    
    init(
        title: String,
        fileName: String,
        date: Date,
        duration: TimeInterval
    ) {
        self.id = UUID()
        self.title = title
        self.fileName = fileName
        self.date = date
        self.duration = duration
    }

    var fileURL: URL {
        let docs = FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        )[0]
        
        return docs.appendingPathComponent(fileName)
    }
    
    var formattedDate: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    var formattedDuration: String {
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

enum RecordingType: String, CaseIterable {
    case all
    case shared
    case starred

    var displayName: String {
        switch self {
            case .all:
            return LocalisationStrings.all.text
            
        case .shared:
            return LocalisationStrings.shared.text
            
        case .starred:
            return LocalisationStrings.starred.text
        }
    }
    
    var emptyStateTitle: String {
        switch self {
        case .all:
            return LocalisationStrings.noRecordingsYet.text

        case .shared:
            return LocalisationStrings.noSharedRecordings.text

        case .starred:
            return LocalisationStrings.noStarredRecordings.text
        }
    }

    var emptyStateMessage: String {
        switch self {
        case .all:
            return LocalisationStrings.tapBelowToStart.text

        case .shared:
            return LocalisationStrings.sharedRecordingsMessage.text

        case .starred:
            return LocalisationStrings.starredRecordingsMessage.text
        }
    }
}

enum RecordingError: Error, LocalizedError {
    case engineCreationFailed
    case noInputNode
    case fileCreationFailed
    case invalidFormat
    
    var errorDescription: String? {
        switch self {
        case .engineCreationFailed: return "Failed to create audio engine"
        case .noInputNode: return "No audio input available"
        case .fileCreationFailed: return "Failed to create audio file"
        case .invalidFormat: return "Microphone format unavailable — try again"
        }
    }
}

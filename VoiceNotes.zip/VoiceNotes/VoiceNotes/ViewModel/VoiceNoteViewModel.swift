//
//  VoiceNoteViewModel.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import Foundation
import AVFoundation
import Combine
import SwiftUI
import SwiftData

class VoiceNoteViewModel: ObservableObject {
    // MARK: - Recording State
    @Published var isRecording = false
    @Published var recordingDuration: TimeInterval = 0
    @Published var waveformSamples: [Float] = Array(repeating: 0, count: 60)
    @Published var meteringLevel: Float = 0
    
    // MARK: - Playback State
    @Published var selectedRecording: Recording?
    @Published var isPlayerSheetPresented = false
    
    // MARK: - UI State
    @Published var showRenameAlert = false
    @Published var recordingToRename: Recording?
    @Published var newTitle = ""
    @Published var permissionDenied = false
    @Published var errorMessage: String?
    @Published var searchText: String = ""
    @Published var selectedFilter: RecordingType = .all
    
    // MARK: - Services
    let recorderService = AudioRecorderService()
    let playerService = AudioPlayerService()
    
    // MARK: - SwiftData
    var modelContext: ModelContext?
    
    private var cancellables = Set<AnyCancellable>()
    private var currentRecordingURL: URL?
    
    init() {
        bindRecorder()
        recorderService.prepareSession()
    }
    
    private func bindRecorder() {
        recorderService.$isRecording
            .receive(on: DispatchQueue.main)
            .assign(to: &$isRecording)
        
        recorderService.$waveformSamples
            .receive(on: DispatchQueue.main)
            .assign(to: &$waveformSamples)
        
        recorderService.$meteringLevel
            .receive(on: DispatchQueue.main)
            .assign(to: &$meteringLevel)
        
        recorderService.$recordingDuration
            .receive(on: DispatchQueue.main)
            .assign(to: &$recordingDuration)
    }
    
    func toggleRecording() {
        if isRecording {
            finishRecording()
        } else {
            requestMicPermissionAndRecord()
        }
    }
    
    private func requestMicPermissionAndRecord() {
        AVAudioApplication.requestRecordPermission { [weak self] granted in
            DispatchQueue.main.async {
                if granted {
                    self?.startRecording()
                } else {
                    self?.permissionDenied = true
                }
            }
        }
    }
    
    private func startRecording() {
        playerService.stop()
        do {
            let url = try recorderService.startRecording()
            currentRecordingURL = url
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    private func finishRecording() {
        guard let context = modelContext,
              let result = recorderService.stopRecording() else { return }
        
        let recording = Recording(
            title: generateTitle(),
            fileName: result.url.lastPathComponent,
            date: Date(),
            duration: result.duration
        )
        
        context.insert(recording)
        
        do {
            try context.save()
        } catch {
            
        }
    }
    
    // MARK: - Playback Actions
    func selectRecordingLongPress(_ recording: Recording) {
        selectedRecording = recording
        playerService.play(url: recording.fileURL)
        isPlayerSheetPresented = true
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
    
    func selectRecording(_ recording: Recording) {
        let exists = FileManager.default.fileExists(
            atPath: recording.fileURL.path
        )
        
        guard exists else { return }
        
        if playerService.currentURL == recording.fileURL {
            playerService.togglePlayPause()
        } else {
            playerService.play(url: recording.fileURL)
        }
    }
    
    func dismissPlayer() {
        playerService.stop()
        isPlayerSheetPresented = false
        selectedRecording = nil
    }
    
    func deleteRecording(_ recording: Recording) {
        guard let context = modelContext else { return }
        if selectedRecording?.id == recording.id {
            dismissPlayer()
        }
        
        try? FileManager.default.removeItem(at: recording.fileURL)
        context.delete(recording)
        try? context.save()
    }
    
    func beginRename(_ recording: Recording) {
        recordingToRename = recording
        newTitle = recording.title
        showRenameAlert = true
    }
    
    func confirmRename() {
        guard let recording = recordingToRename,
              let context = modelContext,
              !newTitle.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        recording.title = newTitle.trimmingCharacters(in: .whitespaces)
        try? context.save()
        recordingToRename = nil
        newTitle = ""
    }
    
    // Add the action
    func togglePauseRecording() {
        recorderService.togglePause()
    }
    
    private func generateTitle() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, h:mm a"
        return "Recording \(formatter.string(from: Date()))"
    }
    
    func filteredRecordings(from recordings: [Recording]) -> [Recording] {
        let searchQuery = searchText
            .trimmingCharacters(in: .whitespacesAndNewlines)

        var filtered = recordings

        // Filter tabs
        switch selectedFilter {
        case .all:
            break

        case .shared:
            filtered = filtered.filter { $0.isShared }

        case .starred:
            filtered = filtered.filter { $0.isStarred }
        }

        // Search filter
        if !searchQuery.isEmpty {
            filtered = filtered.filter {
                $0.title.localizedCaseInsensitiveContains(searchQuery)
            }
        }

        return filtered
    }
}

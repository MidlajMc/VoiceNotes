//
//  AudioPlayerService.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import Foundation
import AVFoundation
import Combine

class AudioPlayerService: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published var isPlaying = false
    @Published var currentTime: TimeInterval = 0
    @Published var duration: TimeInterval = 0
    @Published var playbackProgress: Double = 0
    @Published var currentURL: URL?

    private var player: AVAudioPlayer?
    private var progressTimer: Timer?
    var onPlaybackFinished: (() -> Void)?

    func load(url: URL) {
        stop()
        
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker, .allowBluetoothHFP])
        try? session.setActive(true)

        guard FileManager.default.fileExists(atPath: url.path) else { return }

        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.delegate = self
            player?.prepareToPlay()
            duration = player?.duration ?? 0
            currentTime = 0
            playbackProgress = 0
        } catch {
           
        }
    }

    func play(url: URL) {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker, .allowBluetoothHFP])
        try? session.setActive(true)

        if currentURL == url {
            player?.play()
            isPlaying = true
            startProgressTimer()
        } else {
            stop()
            currentURL = url
            
            guard FileManager.default.fileExists(atPath: url.path) else {
                return
            }

            do {
                player = try AVAudioPlayer(contentsOf: url)
                player?.delegate = self
                player?.prepareToPlay()
                duration = player?.duration ?? 0
                currentTime = 0
                playbackProgress = 0
                player?.play()
                isPlaying = true
                startProgressTimer()
            } catch {
                currentURL = nil
            }
        }
    }

    func pause() {
        player?.pause()
        isPlaying = false
        stopProgressTimer()
    }

    func stop() {
        player?.stop()
        player = nil
        isPlaying = false
        currentURL = nil
        currentTime = 0
        playbackProgress = 0
        duration = 0
        stopProgressTimer()
    }

    func togglePlayPause() {
        guard let url = currentURL else { return }
        if isPlaying {
            pause()
        } else {
            play(url: url)
        }
    }

    func seek(to progress: Double) {
        guard let player = player else { return }
        let time = progress * player.duration
        player.currentTime = time
        currentTime = time
        playbackProgress = progress
    }

    private func startProgressTimer() {
        progressTimer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { [weak self] _ in
            self?.updateProgress()
        }
    }

    private func stopProgressTimer() {
        progressTimer?.invalidate()
        progressTimer = nil
    }

    private func updateProgress() {
        guard let player = player else { return }
        currentTime = player.currentTime
        if player.duration > 0 {
            playbackProgress = player.currentTime / player.duration
        }
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        DispatchQueue.main.async { [weak self] in
            self?.isPlaying = false
            self?.currentTime = 0
            self?.playbackProgress = 0
            self?.stopProgressTimer()
            self?.onPlaybackFinished?()
        }
    }

    var formattedCurrentTime: String {
        formatTime(currentTime)
    }

    var formattedDuration: String {
        formatTime(duration)
    }

    private func formatTime(_ time: TimeInterval) -> String {
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

//
//  AudioRecorderService.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import Foundation
import AVFoundation
import Combine

class AudioRecorderService: NSObject, ObservableObject {
    @Published var isRecording = false
    @Published var isPaused = false
    @Published var meteringLevel: Float = 0.0
    @Published var waveformSamples: [Float] = Array(repeating: 0, count: 60)
    @Published var recordingDuration: TimeInterval = 0
    
    private let audioEngine = AVAudioEngine()
    private var audioFile: AVAudioFile?
    private var currentFileURL: URL?
    private var timer: Timer?
    private var recordingStartTime: Date?
    private var pausedTime: Date?
    private var accumulatedPausedDuration: TimeInterval = 0
    private var tapInstalled = false

    private let maxSamples = 60
    
    func prepareSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(
            .playAndRecord,
            mode: .default,
            options: [.defaultToSpeaker, .allowBluetoothHFP]
        )
        try? session.setActive(true)
    }
    
    func startRecording() throws -> URL {
        guard !isRecording else { return currentFileURL! }
        
        let session = AVAudioSession.sharedInstance()
        guard session.availableInputs?.isEmpty == false else {
            throw RecordingError.noInputNode
        }

        let inputNode = audioEngine.inputNode
        let inputFormat = inputNode.inputFormat(forBus: 0)

        guard inputFormat.sampleRate > 0, inputFormat.channelCount > 0 else {
            throw RecordingError.invalidFormat
        }

        let fileURL = generateFileURL()
        currentFileURL = fileURL

        let fileSettings: [String: Any] = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: inputFormat.sampleRate,
            AVNumberOfChannelsKey: inputFormat.channelCount,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        audioFile = try AVAudioFile(forWriting: fileURL, settings: fileSettings)

        if tapInstalled {
            inputNode.removeTap(onBus: 0)
            tapInstalled = false
        }

        inputNode.installTap(onBus: 0, bufferSize: 4096, format: nil) { [weak self] buffer, _ in
            guard let self else { return }
            try? self.audioFile?.write(from: buffer)
            self.processMeteringLevel(buffer: buffer)
        }
        
        tapInstalled = true

        if !audioEngine.isRunning {
            try audioEngine.start()
        }

        isRecording = true
        isPaused = false

        recordingStartTime = Date()
        accumulatedPausedDuration = 0
        pausedTime = nil
        
        startTimer()

        return fileURL
    }
    
    func stopRecording() -> (url: URL, duration: TimeInterval)? {
        guard isRecording, let fileURL = currentFileURL else { return nil }

        stopTimer()
        let duration = recordingDuration

        if tapInstalled {
            audioEngine.inputNode.removeTap(onBus: 0)
            tapInstalled = false
        }
        
        audioEngine.stop()
        audioEngine.reset()
        
        audioFile = nil
        recordingStartTime = nil
        pausedTime = nil
        
        isRecording = false
        isPaused = false
      
        accumulatedPausedDuration = 0
        meteringLevel = 0
        recordingDuration = 0
        
        waveformSamples = Array(repeating: 0, count: maxSamples)
        
        return (fileURL, duration)
    }
    
    private func processMeteringLevel(buffer: AVAudioPCMBuffer) {
        guard let channelData = buffer.floatChannelData?[0] else { return }
        let frameLength = Int(buffer.frameLength)
        guard frameLength > 0 else { return }

        let channelDataArray = Array(UnsafeBufferPointer(start: channelData, count: frameLength))
        let rms = sqrt(channelDataArray.map { $0 * $0 }.reduce(0, +) / Float(frameLength))
        let normalizedLevel = min(max(rms * 10, 0), 1)

        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.meteringLevel = normalizedLevel
            var samples = self.waveformSamples
            samples.append(normalizedLevel)
            if samples.count > self.maxSamples {
                samples.removeFirst(samples.count - self.maxSamples)
            }
            self.waveformSamples = samples
        }
    }

    private func startTimer() {
        stopTimer()

        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            guard let self,
                  let start = self.recordingStartTime else {
                return
            }

            let elapsed =
                Date().timeIntervalSince(start) - self.accumulatedPausedDuration

            self.recordingDuration = max(0, elapsed)
        }
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    func pauseRecording() {
        guard isRecording, !isPaused else { return }

        audioEngine.pause()

        pausedTime = Date()

        stopTimer()
        isPaused = true
        meteringLevel = 0
    }
    
    func resumeRecording() {
        guard isRecording, isPaused else { return }

        if let pausedTime {
            accumulatedPausedDuration += Date().timeIntervalSince(pausedTime)
            self.pausedTime = nil
        }

        try? audioEngine.start()

        isPaused = false
        startTimer()
    }

    func togglePause() {
        isPaused ? resumeRecording() : pauseRecording()
    }
    
    private func generateFileURL() -> URL {
        let filename = "recording_\(Int(Date().timeIntervalSince1970)).m4a"
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent(filename)
    }
    
    var formattedDuration: String {
        let minutes = Int(recordingDuration) / 60
        let seconds = Int(recordingDuration) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

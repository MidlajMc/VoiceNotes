//
//  RecordButtonView.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftUI

struct RecordButton: View {
    let isRecording: Bool
    let action: () -> Void

    @State private var isPressing = false
    @State private var pulseScale: CGFloat = 1.0
    @State private var ringOpacity: Double = 0.0

    var body: some View {
        Button(action: {
            action()
            triggerHaptic()
        }) {
            ZStack {
                if isRecording {
                    Circle()
                        .stroke(Color.red.opacity(0.25), lineWidth: 2)
                        .frame(width: 96, height: 96)
                        .scaleEffect(pulseScale)
                        .opacity(ringOpacity)

                    Circle()
                        .stroke(Color.red.opacity(0.15), lineWidth: 1.5)
                        .frame(width: 112, height: 112)
                        .scaleEffect(pulseScale)
                        .opacity(ringOpacity * 0.6)
                }
                
                Circle()
                    .fill(isRecording ? Color.red : Color.primaryBlue)
                    .frame(width: 72, height: 72)
                    .shadow(color: (isRecording ? Color.red : Color.primaryBlue).opacity(0.4),
                            radius: isRecording ? 12 : 8, x: 0, y: 4)
                
                if isRecording {
                    RoundedRectangle(cornerRadius: 4)
                        .fill(Color.white)
                        .frame(width: 22, height: 22)
                        .transition(.scale.combined(with: .opacity))
                } else {
                    Image(systemName: ImageNames.micIcon)
                        .font(.system(size: 26, weight: .medium))
                        .foregroundColor(.white)
                        .transition(.scale.combined(with: .opacity))
                }
            }
            .scaleEffect(isPressing ? 0.93 : 1.0)
        }
        .buttonStyle(PlainButtonStyle())
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    withAnimation(.easeInOut(duration: 0.1)) { isPressing = true }
                }
                .onEnded { _ in
                    withAnimation(.easeInOut(duration: 0.1)) { isPressing = false }
                }
        )
        .onChange(of: isRecording) {
            if isRecording {
                startPulse()
            } else {
                stopPulse()
            }
        }
    }

    private func startPulse() {
        withAnimation(.easeInOut(duration: 0.3)) {
            ringOpacity = 1.0
        }
        withAnimation(
            .easeInOut(duration: 1.2)
            .repeatForever(autoreverses: true)
        ) {
            pulseScale = 1.25
        }
    }

    private func stopPulse() {
        withAnimation(.easeInOut(duration: 0.3)) {
            pulseScale = 1.0
            ringOpacity = 0
        }
    }

    private func triggerHaptic() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }
}

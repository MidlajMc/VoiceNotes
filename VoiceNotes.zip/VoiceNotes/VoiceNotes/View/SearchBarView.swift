//
//  SearchBarView.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftUI

struct SearchBarView: View {
    @Binding var searchText: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: ImageNames.searchIcon)
                .font(.system(size: 15))
                .foregroundColor(.secondary)

            TextField(LocalisationStrings.search.text, text: $searchText)
                .font(.system(size: 16))
                .foregroundColor(.primary)

            Spacer()

            if searchText.isEmpty {
                Button(action: {}) {
                    HStack(spacing: 6) {
                        Image(systemName: ImageNames.askAiIcon)
                            .font(.system(size: 13))
                        Text(LocalisationStrings.askAi.text)
                            .font(.system(size: 14, weight: .medium))
                    }
                    .foregroundColor(.primary)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(Color.white)
                    .clipShape(Capsule())
                    .shadow(color: .black.opacity(0.12), radius: 4, x: 0, y: 2)
                }
            } else {
                Button {
                    searchText = ""
                } label: {
                    Image(systemName: ImageNames.crossIcon)
                        .font(.system(size: 18))
                        .foregroundColor(.secondary)
                }
                .transition(.scale.combined(with: .opacity))
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}



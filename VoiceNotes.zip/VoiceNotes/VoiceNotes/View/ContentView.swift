//
//  ContentView.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @StateObject var viewModel = VoiceNoteViewModel()
    @EnvironmentObject var keyboard: KeyboardObserver
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Recording.date, order: .reverse) var recordings: [Recording]
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .bottom) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        searchBarView
                        filterTabView
                        condentView
                        spacerView
                    }
                }
                .hideKeyboard()
                
                recordButton
                recordingView
            }
            .ignoresSafeArea(edges: .bottom)
            .navigationTitle(LocalisationStrings.appName.text)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    TopToolbarView()
                }
            }
        }
        .animation(.spring(response: 0.4, dampingFraction: 0.8), value: viewModel.isRecording)
        .task {
            viewModel.modelContext = modelContext
        }
        .sheet(isPresented: $viewModel.isPlayerSheetPresented, onDismiss: viewModel.dismissPlayer) {
            if let recording = viewModel.selectedRecording {
                PlayerSheet(
                    recording: recording,
                    player: viewModel.playerService,
                    onDismiss: viewModel.dismissPlayer
                )
                .presentationDetents([.height(360)])
                .presentationDragIndicator(.hidden)
            }
        }
        .alert(LocalisationStrings.renameRecording.text, isPresented: $viewModel.showRenameAlert) {
            TextField(
                LocalisationStrings.title.text,
                text: $viewModel.newTitle
            )

            Button(LocalisationStrings.cancel.text, role: .cancel) {}
            Button(LocalisationStrings.save.text) {
                viewModel.confirmRename()
            }
        }
        .alert(
            LocalisationStrings.microphoneAccessRequired.text,
            isPresented: $viewModel.permissionDenied
        ) {
            Button(LocalisationStrings.openSettings.text) {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }

            Button(LocalisationStrings.cancel.text, role: .cancel) {}

        } message: {
            Text(LocalisationStrings.microphonePermissionMessage.text)
        }
    }
    
    var voiceNoteList: some View {
        LazyVStack(spacing: 0) {
            ForEach(viewModel.filteredRecordings(from: recordings)
            ) { recording in
                RecordingRowView(
                    recording: recording,
                    onPlay: { viewModel.selectRecording(recording) },
                    onRename: { viewModel.beginRename(recording) },
                    onDelete: { viewModel.deleteRecording(recording) },
                    longPress: { viewModel.selectRecordingLongPress(recording) },
                    player: viewModel.playerService
                )
                Divider()
                    .padding(.leading, 16)
            }
        }
        .padding(.top, 8)
    }
    
    var recordButton: some View {
        VStack {
            Spacer()
            RecordButton(isRecording: viewModel.isRecording) {
                viewModel.toggleRecording()
            }
            .padding(.bottom, 32)
            .opacity(keyboard.isVisible ? 0 : 1)
            .animation(.easeInOut(duration: 0.25), value: keyboard.isVisible)
        }
    }
    
    var spacerView: some View {
        Spacer()
            .frame(height: 120)
    }
    
    @ViewBuilder
    var condentView: some View {
        if viewModel.filteredRecordings(from: recordings).isEmpty {
            EmptyScreen(
                title: viewModel.searchText.isEmpty
                ? viewModel.selectedFilter.emptyStateTitle
                : LocalisationStrings.noMatchingRecordings.text,
                
                message: viewModel.searchText.isEmpty
                ? viewModel.selectedFilter.emptyStateMessage
                : LocalisationStrings.tryDifferentKeyword.text
            )
        } else {
            voiceNoteList
        }
    }
    
    var searchBarView: some View {
        SearchBarView(searchText: $viewModel.searchText)
            .padding(.horizontal, 16)
            .padding(.top, 8)
    }
    
    var filterTabView: some View {
        FilterTabView(selected: $viewModel.selectedFilter)
            .padding(.top, 14)
            .padding(.horizontal, 16)
    }
    
    @ViewBuilder
    var recordingView: some View {
        if viewModel.isRecording {
            RecordingView(
                recorder: viewModel.recorderService,
                formattedDuration: viewModel.recorderService.formattedDuration,
                onStop: { viewModel.toggleRecording() },
                onPauseResume: { viewModel.togglePauseRecording() }
            )
        }
    }
}

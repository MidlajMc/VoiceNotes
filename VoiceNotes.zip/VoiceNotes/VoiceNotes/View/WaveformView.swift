//
//  WaveformView.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftUI
import AVFAudio

struct PlaybackWaveformView: View {
    let samples: [Float]
    var progress: Double = 0
    var tintColor: Color = Color(hex: "5B7BFE")

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                WaveformBarCanvas(samples: samples, color: Color(.systemGray4), barWidth: 2.5, barSpacing: 1.5)
                
                WaveformBarCanvas(samples: samples, color: tintColor, barWidth: 2.5, barSpacing: 1.5)
                    .frame(width: geo.size.width)
                    .clipShape(
                        Rectangle().path(in: CGRect(x: 0, y: 0, width: geo.size.width * progress, height: geo.size.height))
                    )
            }
        }
    }
}

struct WaveformBarCanvas: View {
    let samples: [Float]
    var color: Color
    var barWidth: CGFloat
    var barSpacing: CGFloat

    var body: some View {
        Canvas { context, size in
            let totalBars = samples.count
            let totalBarSpace = CGFloat(totalBars) * (barWidth + barSpacing) - barSpacing
            let startX = (size.width - totalBarSpace) / 2
            let centerY = size.height / 2

            for (i, sample) in samples.enumerated() {
                let x = startX + CGFloat(i) * (barWidth + barSpacing)
                let barH = max(2, CGFloat(sample) * size.height * 0.9)
                let rect = CGRect(x: x, y: centerY - barH / 2, width: barWidth, height: barH)
                let path = Path(roundedRect: rect, cornerRadius: barWidth / 2)
                context.fill(path, with: .color(color))
            }
        }
    }
}

struct StaticWaveformGenerator {
    static func generateSamples(for url: URL, count: Int = 80) -> [Float] {
        guard let file = try? AVAudioFile(forReading: url) else {
            return generateFallback(count: count)
        }

        let format = file.processingFormat
        let frameCount = AVAudioFrameCount(file.length)
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount),
              (try? file.read(into: buffer)) != nil,
              let channelData = buffer.floatChannelData?[0] else {
            return generateFallback(count: count)
        }

        let frames = Int(buffer.frameLength)
        let samplesPerBlock = max(1, frames / count)
        var result: [Float] = []

        for i in 0..<count {
            let start = i * samplesPerBlock
            let end = min(start + samplesPerBlock, frames)
            if start >= end { break }
            let block = (start..<end).map { abs(channelData[$0]) }
            let rms = sqrt(block.map { $0 * $0 }.reduce(0, +) / Float(block.count))
            result.append(min(rms * 8, 1.0))
        }

        return result
    }

    static func generateFallback(count: Int) -> [Float] {
        (0..<count).map { _ in Float.random(in: 0.1...0.6) }
    }
}

struct LiquidWaveView: View {
    var level: Float
    var isPaused: Bool
    var duration: TimeInterval
    var color: Color = .primaryBlue

    @State private var accumulatedTime: Double = 0
    @State private var lastDate: Date? = nil

    var body: some View {
        TimelineView(.animation(minimumInterval: 1/60, paused: isPaused)) { timeline in
            let now = timeline.date
            let elapsed = computeElapsed(now: now)

            Canvas { ctx, size in
                drawWaves(ctx: ctx, size: size, elapsed: elapsed)
            }
        }
        .onChange(of: isPaused) {
            if isPaused {
                accumulatedTime += Date().timeIntervalSince(lastDate ?? Date())
                lastDate = nil
            } else {
                lastDate = Date()
            }
        }
        .onAppear {
            lastDate = Date()
        }
        .animation(.easeInOut(duration: 0.5), value: level)
        .animation(.easeInOut(duration: 0.6), value: isPaused)
        .drawingGroup()
    }

    // MARK: - Time tracking

    private func computeElapsed(now: Date) -> Double {
        guard !isPaused, let last = lastDate else {
            return accumulatedTime
        }
        return accumulatedTime + now.timeIntervalSince(last)
    }

    // MARK: - Drawing
    private func drawWaves(ctx: GraphicsContext, size: CGSize, elapsed: Double) {
        let w = size.width
        let h = size.height
        let durationBoost = min(duration / 300.0, 1.0) * 0.20
        let micBoost = Double(level) * 0.15
        let fillFraction = 0.30 + durationBoost + micBoost
        let fillY = h * (1.0 - min(fillFraction, 0.72))
        let speedMultiplier = isPaused ? 0.15 : (1.0 + min(duration / 120.0, 1.0) * 0.6)
        let baseAmplitude = h * 0.045
        let micAmplitude  = h * 0.07 * Double(level)
        let amplitude1 = (baseAmplitude + micAmplitude) * (isPaused ? 0.4 : 1.0)
        let amplitude2 = amplitude1 * 0.7
        let phase1 = elapsed * 1.4 * speedMultiplier
        let wave1 = wavePath(
            width: w, height: h, fillY: fillY,
            phase: phase1, amplitude: amplitude1,
            frequency: 1.3, horizontalShift: 0
        )
        ctx.fill(wave1, with: .color(color.opacity(0.30)))
        
        let phase2 = -elapsed * 1.9 * speedMultiplier + .pi * 0.5
        let wave2 = wavePath(
            width: w, height: h, fillY: fillY - 4,
            phase: phase2, amplitude: amplitude2,
            frequency: 1.7, horizontalShift: w * 0.1
        )
        ctx.fill(wave2, with: .color(color.opacity(0.45)))

        let phase3 = elapsed * 2.5 * speedMultiplier + .pi
        let wave3 = wavePath(
            width: w, height: h, fillY: fillY - 2,
            phase: phase3, amplitude: amplitude1 * 0.85,
            frequency: 2.1, horizontalShift: -w * 0.05
        )
        ctx.fill(wave3, with: .color(color.opacity(0.65)))
    }

    // MARK: - Wave path builder
    private func wavePath(
        width: CGFloat, height: CGFloat,
        fillY: CGFloat, phase: Double,
        amplitude: Double, frequency: Double,
        horizontalShift: CGFloat
    ) -> Path {
        Path { path in
            let steps = Int(width)
            guard steps > 0 else { return }

            path.move(to: CGPoint(x: 0, y: height))

            for x in 0...steps {
                let progress = Double(x) / Double(width)
                let angle1 = progress * frequency * 2 * .pi + phase
                let angle2 = progress * frequency * 4 * .pi + phase * 1.3
                let y = fillY
                    + CGFloat(sin(angle1) * amplitude)
                    + CGFloat(sin(angle2) * amplitude * 0.25)
                    + horizontalShift * 0

                if x == 0 {
                    path.move(to: CGPoint(x: 0, y: y))
                } else {
                    path.addLine(to: CGPoint(x: CGFloat(x), y: y))
                }
            }

            path.addLine(to: CGPoint(x: width, y: height))
            path.addLine(to: CGPoint(x: 0, y: height))
            path.closeSubpath()
        }
    }
}

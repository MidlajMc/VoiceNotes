//
//  TopToolbarView.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftUI

struct TopToolbarView: View {
    var plusAction: () -> Void = { }
    var calendarAction: () -> Void = { }
    var settingsAction: () -> Void = { }
    
    var body: some View {
        HStack(spacing: 16) {
            Button(action: {
                plusAction()
            }) {
                Image(systemName: ImageNames.plusIcon)
                    .font(.system(size: 16, weight: .medium))
            }
            
            Button(action: {
                calendarAction()
            }) {
                Image(systemName: ImageNames.calendarIcon)
                    .font(.system(size: 16))
            }
            
            Button(action: {
                settingsAction()
            }) {
                Image(systemName: ImageNames.settingsIcon)
                    .font(.system(size: 16))
            }
        }
        .foregroundColor(.primary)
    }
}


//
//  RecordingRowView.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftUI

struct RecordingRowView: View {
    let recording: Recording
    let onPlay: () -> Void
    let onRename: () -> Void
    let onDelete: () -> Void
    let longPress: () -> Void

    @ObservedObject var player: AudioPlayerService

    var isCurrentlyPlaying: Bool {
        player.currentURL == recording.fileURL && player.isPlaying
    }

    var isCurrentlyLoaded: Bool {
        player.currentURL == recording.fileURL
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let date = formattedDateComponents {
                Text(date)
                    .font(.system(size: 12, weight: .regular))
                    .foregroundColor(.secondary)
            }
            
            Text(recording.title)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(.primary)
                .lineLimit(2)
            
            HStack {
                scrubberPill
                
                Spacer()
                
                actionButtons
            }
        }
        .padding(.vertical, 14)
        .padding(.horizontal, 16)
        .contentShape(Rectangle())
        .onLongPressGesture { longPress() }
        .animation(.spring(response: 0.35, dampingFraction: 0.8), value: isCurrentlyLoaded)
    }

    var scrubberPill: some View {
        HStack(spacing: 10) {
            playButtonView

            if isCurrentlyLoaded {
                audioTrackView
            }
            
            audioDurationView
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color(.systemGray6))
        .clipShape(Capsule())
    }

    // MARK: - Action buttons

    var actionButtons: some View {
        HStack(spacing: 8) {
            iconButton(
                systemName: ImageNames.docIcon,
                action: {
                })
            
            iconButton(
                systemName: ImageNames.pencilIcon,
                action: onRename
            )
            
            iconButton(
                systemName: ImageNames.shareIcon,
                action: {
                })
            
            Menu {
                Button(LocalisationStrings.delete.text, role: .destructive) {
                    onDelete()
                }
            } label: {
                Image(systemName: ImageNames.optionsIcon)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.primary)
                    .frame(width: 36, height: 36)
                    .background(Color(.systemGray6))
                    .clipShape(Circle())
            }
        }
    }

    func iconButton(systemName: ImageNames, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.primary)
                .frame(width: 36, height: 36)
                .background(Color(.systemGray6))
                .clipShape(Circle())
        }
        .buttonStyle(PlainButtonStyle())
    }

    var formattedDateComponents: String? {
        let f = DateFormatter()
        f.dateFormat = "MMM d  ·  h:mm a"
        return f.string(from: recording.date)
    }
    
    var playButtonView: some View {
        Button(action: {
            if isCurrentlyLoaded {
                player.togglePlayPause()
            } else {
                onPlay()
            }
        }) {
            Image(systemName: isCurrentlyPlaying ? ImageNames.pauseIcon : ImageNames.playIcon)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.primary)
                .frame(width: 16)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    var audioDurationView: some View {
        Text(isCurrentlyLoaded ? player.formattedCurrentTime : recording.formattedDuration)
            .font(.system(size: 13, weight: .medium, design: .monospaced))
            .foregroundColor(.primary)
            .animation(.none, value: isCurrentlyLoaded)
            .fixedSize()
    }
    
    var audioTrackView: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(Color(.systemGray4))
                    .frame(height: 3)
                
                Capsule()
                    .fill(Color.primary)
                    .frame(
                        width: geo.size.width * CGFloat(isCurrentlyLoaded ? player.playbackProgress : 0),
                        height: 3
                    )
                
                Circle()
                    .fill(Color.primary)
                    .frame(width: 14, height: 14)
                    .offset(x: geo.size.width * CGFloat(isCurrentlyLoaded ? player.playbackProgress : 0) - 7)
            }
            .frame(maxHeight: .infinity)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        guard isCurrentlyLoaded else { return }
                        let progress = max(0, min(1, value.location.x / geo.size.width))
                        player.seek(to: progress)
                    }
            )
        }
        .frame(height: 20)
    }
}

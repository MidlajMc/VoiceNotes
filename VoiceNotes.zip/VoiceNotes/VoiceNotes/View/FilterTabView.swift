//
//  FilterTabView.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftUI

struct FilterTabView: View {
    @Binding var selected: RecordingType
    
    var body: some View {
        HStack(spacing: 8) {
            ForEach(RecordingType.allCases, id: \.self) { type in
                Button(action: {
                    selected = type
                }) {
                    Text(type.displayName)
                        .font(.system(size: 14, weight: selected == type ? .semibold : .regular))
                        .foregroundColor(selected == type ? .primary : .secondary)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 7)
                        .background(
                            selected == type
                            ? Color(.systemGray5)
                            : Color.clear
                        )
                        .clipShape(Capsule())
                }
                .buttonStyle(PlainButtonStyle())
            }
            Spacer()
        }
    }
}


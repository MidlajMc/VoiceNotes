//
//  RecordingOverlayView.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftUI

struct RecordingView: View {
    @ObservedObject var recorder: AudioRecorderService
    let formattedDuration: String
    let onStop: () -> Void
    let onPauseResume: () -> Void
    
    var body: some View {
        VStack(spacing: 14) {
            pauseButtonView
            doneButtonView
        }
        .padding()
        .padding(.top, 10)
        .background(Color(.systemBackground))
        .cornerRadius(30)
        .transition(.move(edge: .bottom).combined(with: .opacity))
        .shadow(color: .black.opacity(0.08), radius: 20, x: 0, y: -4)
        .overlay(
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .strokeBorder(
                    Color(.systemGray4),
                    lineWidth: 1.5
                )
        )
        .overlay(alignment: .top) {
            dismissChevronView
                .offset(y: -18)
        }
        .padding(.horizontal)
        .padding(.bottom)
    }
    
    var pauseButtonView: some View {
        ZStack {
            LiquidWaveView(
                level: recorder.meteringLevel,
                isPaused: recorder.isPaused,
                duration: recorder.recordingDuration
            )
            
            Color.black.opacity(0.08)

            HStack(spacing: 8) {
                recordedAudioIconView
                audioDurationView
            }
        }
        .frame(height: 65)
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Color(.systemGray6))
        )
        .animation(.easeInOut(duration: 0.3), value: recorder.isPaused)
        .onTapGesture {
            onPauseResume()
        }
    }
    
    var doneButtonView: some View {
        Button(action: onStop) {
            HStack(spacing: 8) {
                Image(systemName: ImageNames.checkmarkIcon)
                Text(LocalisationStrings.done.text)
            }
            .font(.system(size: 18, weight: .semibold))
            .foregroundColor(.primaryGreen)
            .frame(maxWidth: .infinity)
            .frame(height: 65)
            .background(Color.primaryGreen.opacity(0.1))
            .cornerRadius(24)
        }
        .disabled(recorder.recordingDuration == 0)
        .opacity(recorder.recordingDuration == 0 ? 0.3 : 1)
    }
    
    var recordedAudioIconView: some View {
        Image(systemName: recorder.isPaused ? ImageNames.pauseIcon : ImageNames.waveform)
            .font(.system(size: 14, weight: .semibold))
            .foregroundColor(.black)
            .symbolEffect(.variableColor.iterative, isActive: !recorder.isPaused)
    }
    
    var audioDurationView: some View {
        Text(formattedDuration)
            .font(.system(size: 20, weight: .semibold, design: .monospaced))
            .foregroundColor(.black)
    }
    
    var dismissChevronView: some View {
        Button(action: onStop) {
            Image(systemName: ImageNames.chevronUp)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(Color(.systemGray))
                .frame(width: 32, height: 32)
                .background(
                    Circle()
                        .fill(Color(.systemBackground))
                        .strokeBorder(Color(.systemGray4), lineWidth: 1.5)
                )
            
        }
    }
}

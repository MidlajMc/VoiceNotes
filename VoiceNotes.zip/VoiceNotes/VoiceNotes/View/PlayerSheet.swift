//
//  PlayerSheet.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import SwiftUI

struct PlayerSheet: View {
    let recording: Recording
    @ObservedObject var player: AudioPlayerService
    let onDismiss: () -> Void

    @State private var waveformSamples: [Float] = []
    @State private var isDraggingSeek = false
    @State private var dragProgress: Double = 0

    var body: some View {
        VStack(spacing: 20) {
            titleView
            progressView
            durationView
            
            HStack(spacing: 40) {
                backwardButton
                playButton
                forwardButton
            }
            .padding(.vertical, 8)
            
            closeButton
        }
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .onAppear {
            loadWaveform()
        }
        .onDisappear {
            player.stop()
        }
    }

    private var titleView: some View {
        VStack(spacing: 4) {
            Text(recording.title)
                .font(.system(size: 17, weight: .semibold))
                .lineLimit(2)
                .multilineTextAlignment(.center)
            Text(recording.formattedDate)
                .font(.system(size: 13))
                .foregroundColor(.secondary)
        }
        .padding(.horizontal, 24)
        .padding(.top)
    }
    
    private var progressView: some View {
        GeometryReader { geometry in
            ZStack {
                if waveformSamples.isEmpty {
                    ProgressBar(
                        progress: isDraggingSeek
                        ? dragProgress
                        : player.playbackProgress
                    )
                } else {
                    PlaybackWaveformView(
                        samples: waveformSamples,
                        progress: isDraggingSeek
                        ? dragProgress
                        : player.playbackProgress
                    )
                }
            }
            .contentShape(Rectangle())
            .gesture(seekGesture(width: geometry.size.width))
        }
        .frame(height: 56)
        .padding(.horizontal, 24)
    }
    
    private var durationView: some View {
        HStack {
            Text(isDraggingSeek ? formatTime(dragProgress * player.duration) : player.formattedCurrentTime)
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.secondary)
            Spacer()
            Text(player.formattedDuration)
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.secondary)
        }
        .padding(.horizontal, 24)
    }
    
    private var backwardButton: some View {
        Button(action: {
            let newProgress = max(0, player.playbackProgress - (10 / player.duration))
            player.seek(to: newProgress)
        }) {
            Image(systemName: ImageNames.backwardIcon)
                .font(.system(size: 28))
                .foregroundColor(.primary)
        }
    }
    
    private var playButton: some View {
        Button(action: { player.togglePlayPause() }) {
            ZStack {
                Circle()
                    .fill(Color.primaryBlue)
                    .frame(width: 60, height: 60)
                    .shadow(color: Color.primaryBlue.opacity(0.35), radius: 10, x: 0, y: 4)
                
                Image(systemName: player.isPlaying ? ImageNames.pauseIcon : ImageNames.playIcon)
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundColor(.white)
                    .offset(x: player.isPlaying ? 0 : 2)
            }
        }
        .animation(.easeInOut(duration: 0.15), value: player.isPlaying)
    }
    
    private var forwardButton: some View {
        Button(action: {
            let newProgress = min(1, player.playbackProgress + (10 / player.duration))
            player.seek(to: newProgress)
        }) {
            Image(systemName: ImageNames.forwardIcon)
                .font(.system(size: 28))
                .foregroundColor(.primary)
        }
    }
    
    private var closeButton: some View {
        Button(action: {
            player.stop()
            onDismiss()
        }) {
            Text(LocalisationStrings.done.text)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(Color.primaryBlue)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(Color.primaryBlue.opacity(0.15))
                .clipShape(RoundedRectangle(cornerRadius: 14))
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 32)
    }
    
    private func seekGesture(width: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { value in
                isDraggingSeek = true
                dragProgress = max(0, min(1, value.location.x / width))
            }
            .onEnded { _ in
                player.seek(to: dragProgress)
                isDraggingSeek = false
            }
    }

    private func loadWaveform() {
        DispatchQueue.global(qos: .userInitiated).async {
            let samples = StaticWaveformGenerator.generateSamples(for: recording.fileURL, count: 80)
            DispatchQueue.main.async {
                waveformSamples = samples
            }
        }
    }

    private func formatTime(_ time: TimeInterval) -> String {
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

struct ProgressBar: View {
    var progress: Double

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(Color(.systemGray5))
                    .frame(height: 4)

                Capsule()
                    .fill(Color(hex: "5B7BFE"))
                    .frame(width: geo.size.width * CGFloat(progress), height: 4)
            }
            .frame(maxHeight: .infinity)
        }
    }
}

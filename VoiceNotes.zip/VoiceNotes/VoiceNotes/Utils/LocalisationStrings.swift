//
//  LocalisationStrings.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import Foundation

enum LocalisationStrings: String {
    case appName = "Voice Notes"
    
    // Rename Alert
    case renameRecording = "Rename Recording"
    case title = "Title"
    case cancel = "Cancel"
    case save = "Save"
    
    // Permission Alert
    case microphoneAccessRequired = "Microphone Access Required"
    case openSettings = "Open Settings"
    case microphonePermissionMessage = "Please allow microphone access in Settings to record audio."
    
    case done = "Done"
    case delete = "Delete"
    case askAi = "Ask AI"
    case search = "Search"
    
    // Filter Tabs
    case all = "All"
    case shared = "Shared"
    case starred = "Starred"
    
    // Empty Screen
    case noMatchingRecordings = "No matching recordings"
    case tryDifferentKeyword = "Try a different keyword"
    case noRecordingsYet = "No recordings yet"
    case tapBelowToStart = "Tap the button below to start"
    case noSharedRecordings = "No shared recordings"
    case sharedRecordingsMessage = "Shared recordings will appear here"
    case noStarredRecordings = "No starred recordings"
    case starredRecordingsMessage = "Starred recordings will appear here"
    
    var text: String {
        rawValue
    }
}

//
//  ImageNames.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import Foundation
import SwiftUI

enum ImageNames: String {
    case plusIcon = "plus"
    case calendarIcon = "calendar"
    case settingsIcon = "gearshape"
    case searchIcon = "magnifyingglass"
    case askAiIcon = "brain.head.profile.fill"
    case emptyVoiceIcon = "waveform.circle"
    case checkmarkIcon = "checkmark"
    case pauseIcon = "pause.fill"
    case playIcon = "play.fill"
    case waveform = "waveform"
    case chevronUp = "chevron.up"
    case micIcon = "mic.fill"
    case docIcon = "doc.text"
    case pencilIcon = "pencil"
    case shareIcon = "paperplane"
    case optionsIcon = "ellipsis"
    case crossIcon = "xmark.circle.fill"
    case backwardIcon = "gobackward.10"
    case forwardIcon = "goforward.10"
}

extension Image {
    init(_ name: ImageNames) {
        self.init(name.rawValue)
    }

    init(systemName name: ImageNames) {
        self.init(systemName: name.rawValue)
    }
}

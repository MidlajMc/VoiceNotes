//
//  KeyboardObserver.swift
//  VoiceNotes
//
//  Created by Midlaj Mc on 12/05/26.
//

import Combine
import UIKit

class KeyboardObserver: ObservableObject {
    @Published var isVisible = false
    
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)
            .map { _ in true }
            .merge(with:
                NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)
                    .map { _ in false }
            )
            .receive(on: DispatchQueue.main)
            .assign(to: &$isVisible)
    }
}
